<?php include 'header.php'; ?>

<body>
    <?php include 'navbar.php'; ?>
    <div class="page-content">
        <div class="container h-100">
            <div class="items-center flex flex-column flex-gap justify-center w-100 h-100">
                <img class="" src="https://www12.0zz0.com/2024/10/02/02/860951848.png" width="150" height="200">
                <form class="row row-cols-3 g-2 justify-content-center align-items-center w-100">
                    <div>
                        <p class="text-green fw-bold">* الاسم الاول: </p>
                        <input type="text" class="input">
                    </div>
                    <div>
                        <p class="text-green fw-bold">* الاسم الاخير: </p>
                        <input type="text" class="input">
                    </div>
                    <div>
                        <p class="text-green fw-bold">* الرقم الجوال: </p>
                        <input type="tel" class="input">
                    </div>
                    <div>
                        <p class="text-green fw-bold">* كلمة المرور: </p>
                        <input type="password" class="input">
                    </div>
                    <div>
                        <p class="text-green fw-bold">* تاكيد كلمة المرور: </p>
                        <input type="password" class="input">
                    </div>
                    <div>
                        <p class="text-green fw-bold">* البريد الالكتروني: </p>
                        <input type="email" class="input">
                    </div>
                </form>
                <div class="d-flex justify-content-end w-100 mt-4">
                    <button class="btn-green rounded-large">التالي</button>
                </div>
            </div>
        </div>
    </div>
    <!-- footer -->
    <?php include 'footer.php'; ?>
    
</body>

</html>