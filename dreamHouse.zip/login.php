<?php include 'header.php'; ?>

<body>
    <?php include 'navbar.php'; ?>
    <div class="page-content">
        <div class="container h-100">
            <div class="flex justify-center items-center w-100 h-100 flex-column flex-gap">
                <form class="">
                    <div>
                        <p class="text-green fw-bold">* الايميل: </p>
                        <input type="email" class="input mt-3">
                    </div>
                    <div class="mt-4">
                        <p class="text-green fw-bold">* كلمة المرور: </p>
                        <input type="password" class="input mt-3">
                    </div>
                </form>
                <div class="mt-4">
                    <button class="btn-green rounded-large">تسجيل الدخول</button>
                </div>
            </div>
        </div>
    </div>
    <!-- footer -->
    <footer class="container flex justify-evenly items-center">
        <div class="flex justify-center items-center">
            <img src="assets/images/contact/whatsapp.png" width="70" height="70">
            <a class="decoration-none text-green fw-bold" href="https://api.whatsapp.com/send/?phone=966500862595&text&type=phone_number&app_absent=0">خدمة
                العملاء</a>
        </div>
        <div class="flex justify-center items-center">
            <img src="assets/images/contact/instgram.png" width="70" height="90">
            <a class="decoration-none text-green fw-bold" href="https://api.whatsapp.com/send/?phone=966500862595&text&type=phone_number&app_absent=0">Dream_house</a>
        </div>
        <div class="flex justify-center items-center">
            <img src="assets/images/contact/whatsapp.png" width="70" height="70">
            <a class="decoration-none text-green fw-bold" href="https://api.whatsapp.com/send/?phone=966500862595&text&type=phone_number&app_absent=0">0552363908</a>
        </div>
    </footer>
</body>

</html>