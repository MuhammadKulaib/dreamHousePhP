<!DOCTYPE html>
<html lang="ar" dir="rtl">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="assets/fontawesome-free-6.5.2-web/css/all.css">
    <link rel="stylesheet" href="assets/bootstrap/bootstrap.rtl.min.css">
    <link rel="stylesheet" href="assets/css/style.css">
    <script src="assets/bootstrap/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-element-bundle.min.js"></script>
    <title>Page3</title>
</head>
