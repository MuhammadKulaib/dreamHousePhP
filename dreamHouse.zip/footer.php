<footer class="footer row row-cols-3 py-2">
    <div class="d-flex justify-content-center align-items-center">
        <div style="height: 70px; width: 70px;">
            <img class="h-100 w-100" src="assets/images/contact/whatsapp.png">
        </div>
        <a class="text-decoration-none text-green fw-bold" href="https://api.whatsapp.com/send/?phone=966500862595&text&type=phone_number&app_absent=0">خدمة
            العملاء</a>
    </div>
    <div class="d-flex justify-content-center align-items-center">
        <div style="height: 90px; width: 70px;">
            <img class="w-100 h-100" src="assets/images/contact/instgram.png">
        </div>
        <a class="text-decoration-none text-green fw-bold" href="https://api.whatsapp.com/send/?phone=966500862595&text&type=phone_number&app_absent=0">Dream_house</a>
    </div>
    <div class="d-flex justify-content-center align-items-center">
        <div style="height: 70px; width: 70px;">
            <img class="h-100 w-100" src="assets/images/contact/whatsapp.png">
        </div>
        <a class="text-decoration-none text-green fw-bold" href="https://api.whatsapp.com/send/?phone=966500862595&text&type=phone_number&app_absent=0">0552363908</a>
    </div>
</footer>