<?php include "header.php" ?>
<div class="d-flex justify-content-around">
                <div class="rounded-card large-card flex flex-column items-center justify-center">
                    <img src="assets/images/contact/whatsapp.png" width="122" height="122">
                    <a class="decoration-none main-color text-large" href="https://api.whatsapp.com/send/?phone=966500862595&text&type=phone_number&app_absent=0">0500862595</a>
                </div>
                <div class="rounded-card large-card flex flex-column items-center justify-center">
                    <img src="assets/images/contact/instgram.png" width="130" height="163">
                    <a class="decoration-none main-color text-large" href="https://x.com/dreamh5490/">Dream_house</a>
                </div>
                <div class="rounded-card large-card flex flex-column items-center justify-center">
                    <img src="assets/images/contact/x-twitter.png" width="92" height="94">
                    <a class="decoration-none main-color text-large" href="https://x.com/dreamh5490/">Dream_house</a>
                </div>
            </div>
</div>
<?php  include "footer.php" ?>