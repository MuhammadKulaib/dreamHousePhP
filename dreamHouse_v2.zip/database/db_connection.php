<?php

$conn = mysqli_connect('localhost','root','','dream_house');

?>